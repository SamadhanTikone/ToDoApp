
import java.util.*;

public class ToDoList {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.err.println("Welcome to the To-Do List App ");
        System.err.println("1: Add Task ");
        System.err.println("2: View Task ");
        System.err.println("3: Mark Task as Completed ");
        System.err.println("4: Delete Task ");
        System.err.println("5:Exit");

        for (int i = 1; i <= 5; i++) {

            System.err.println("Enter your choice:");

            int num = scan.nextInt();

            TakeTask newTask = new TakeTask();
            ShowTask data = new ShowTask();

            if (num == 1) {
                newTask.takeTask();
            } else if (num == 2) {
                data.showTask();

            } else if (num == 3) {

                // setmarked();
            } else if (num == 4) {

            } else if (num == 5) {
                System.err.println("GoodBye!!");
                i = 6;
                break;

            } else {
                System.err.println("Check Your Choice");
            }

        }

    }
}

class TakeTask {

    Scanner scan = new Scanner(System.in);
    static String task;

    int id = 0;

    // String newTask = scan.nextLine();
    String takeTask() {
        System.out.println("Enter Task Title:");

        task = scan.nextLine();

        id++;

        // System.err.println("Your task is: " + task);
        System.err.println("task Added with:" + id);

        return task;
    }

}

class ShowTask extends TakeTask {

    // TakeTask newTask = new TakeTask();
    void showTask() {
        String tasks = TakeTask.task;
        System.out.println(tasks);
    }
}
